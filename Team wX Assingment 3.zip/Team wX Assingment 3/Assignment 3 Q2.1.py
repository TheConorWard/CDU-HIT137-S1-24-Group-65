import pygame
import os
import csv

pygame.init()


SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 700

screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption('run and gun')


#frame rate
clock = pygame.time.Clock()
FPS = 60

#game variables
GRAVITY = .75
ROWS = 16
COLS = 150
level = 1
TILE_SIZE = SCREEN_HEIGHT // ROWS
start_game = False



#player action variables
moving_left = False
moving_right = False
shoot = False

#load images

#backgrounds
background_image = pygame.image.load("img\icons\BG.png")

#magic
magic_image = pygame.image.load("img\icons\magic.png")
#item boxs
heal_box_image = pygame.image.load("img\icons\heart.png")
mana_pot_image =  pygame.image.load("img\icons\mana.png")

item_boxes = {
    'heal'      :heal_box_image,
    'mana'      :mana_pot_image
}

#colours

BG = (128, 126, 239)
Floor = ( 150, 75, 0)
BLACK = (0, 255, 0)
BLUE = (0, 0, 255)
RED = (255, 0, 0)

#defeine.font
font = pygame.font.SysFont('forte', 30)

def draw_text(text, font, text_col, x, y):
    img = font.render(text, True, text_col)
    screen.blit(img, (x, y))


def draw_bg():
    screen.fill(BG)
    img = background_image
    screen.blit(img, (0, 0))
    
    pygame.draw.line(screen, Floor, (0, 699), (SCREEN_WIDTH, 699))



class Human(pygame.sprite.Sprite):
    def __init__(self, char_type, x, y, scale, speed, mp):
        pygame.sprite.Sprite.__init__(self)
        self.alive = True
        self.char_type = char_type
        self.speed = speed 
        self.mp = mp
        self.start_mp = mp
        self.max_mp = self.mp
        self.shoot_cooldown = 0
        self.health = 100
        self.max_health = self.health
        self.direction = 1
        self.vel_y = 0
        self.jump = False
        self.in_air = True
        self.flip = False
        self.animation_list = []
        self.frame_index = 0
        self.action = 0
        self.update_time = pygame.time.get_ticks()
        self.score = 0
        self.score_incement = 10


        #ai variables
        self.move_counter = 0   
        self.vision = pygame.Rect(0, 0, 50, 50)  
     
        #load all imaged
        animation_types = ['Idle', 'jump', 'move', 'death'] 
        for animation in animation_types:   
           #reset temp list of images
            temp_list = []
            #count number of files
            num_of_frames = len(os.listdir(f'img\{self.char_type}\{animation}'))

            for i in range(num_of_frames):
                img = pygame.image.load(f"img\{self.char_type}\{animation}\{i}.png").convert_alpha()
                img= pygame.transform.scale(img, (int(img.get_width() * scale), int(img.get_height() * scale)))
                temp_list.append(img)
            self.animation_list.append(temp_list)
          
            self.image = self.animation_list[self.action][self.frame_index]
            self.rect = self.image.get_rect()
            self.rect.center = (x, y)

    def update(self):
        self.update_animation()
        self.check_alive()
		#update cooldown
        if self.shoot_cooldown > 0:
            self.shoot_cooldown -= 1

    def move(self, moving_left, moving_right):
        #reset variables
        SCREEN_SCROOL = 0

        dx = 0
        dy = 0

        #moving the character
        #left and right
        if moving_left:
            dx = -self.speed
            self.flip = True
            self.direction = -1
        if moving_right:
            dx = self.speed
            self.flip = False
            self.direction = 1

            #jumping
        if self.jump == True and self.in_air == False:
            self.vel_y = -15
            self.jump = False
            self.in_air = True


        #gravity
        self.vel_y += GRAVITY
        if self.vel_y > 10:
            self.vel_y = 10
        dy += self.vel_y

        #check collision with floor
        if self.rect.bottom + dy > 699:
            dy = 699 - self.rect.bottom
            self.in_air = False

        #wall collision
        if self.rect.left + dx < 0 or self.rect.right + dx > SCREEN_WIDTH:
            self.direction *= -1
            dx = self.direction * self.speed

        #update pos
        self.rect.x += dx
        self.rect.y += dy

        
    def shoot(self):
       if self.shoot_cooldown == 0 and self.mp > 0:
        self.shoot_cooldown = 20
        magic = Magic(self.rect.centerx + (1.5 * self.rect.size[0] * self.direction), self.rect.centery, self.direction)
        magic_group.add(magic)
        self.mp -= 1

    def ai(self):
        if self.alive and player.alive:
            if self.vision.colliderect(player.rect):
                player.health -= 2
            if self.direction == 1:
                ai_moving_right = True
            else:
                ai_moving_right = False
            ai_moving_left = not ai_moving_right
            self.move(ai_moving_left, ai_moving_right)
            self.update_action(1)
            self.move_counter += 1
            #ai vision
            self.vision.center = (self.rect.centerx, self.rect.centery)
            

            if self.move_counter > TILE_SIZE:
                self.direction * -1
                self.move_counter *= -1



    def update_animation(self):
        #animatioin update
        ANIMATION_COOLDOWN = 100
        #update dependant on frame
        self.image = self.animation_list[self.action][self.frame_index]
        #check passage of time
        if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
            self.update_time = pygame.time.get_ticks()
            self.frame_index += 1
        if self.frame_index >= len(self.animation_list[self.action]):
            if self.action == 3:
                self.frame_index = len(self.animation_list[self.action]) - 1
            else:
                self.frame_index = 0
        
    def update_action(self, new_action):
        #check if the new action is different
        if new_action != self.action:
            self.action = new_action
            #update animation settings
            self.frame_index = 0
            self.update_time = pygame.time.get_ticks()

    def check_alive(self):
        if self.health <= 0:
            self.health = 0
            self.speed = 0
            self.alive = False
            self.update_action(3)

    def draw(self):
        screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)


class ItemBox(pygame.sprite.Sprite):
    def __init__(self, item_type, x, y, ):
        pygame.sprite.Sprite.__init__(self)
        self.item_type = item_type
        self.image = item_boxes[self.item_type]
        self.rect = self.image.get_rect()
        self.rect.midtop = (x + TILE_SIZE // 2, y + (TILE_SIZE - self.image.get_height()))

    def update(self):
        #check if box is collected
        if pygame.sprite.collide_rect(self, player):
            #check type of box
            if self.item_type == 'heal':
                player.health += 25
                if player.health > player.max_health:
                    player.health = player.max_health
            elif self.item_type == 'mana':
                player.mp += 10
                if player.mp > player.max_mp:
                    player.mp = player.max_mp
            #clear item box
            self.kill()
        



class Magic(pygame.sprite.Sprite):
    def __init__(self, x, y, direction):
        pygame.sprite.Sprite.__init__(self)
        self.speed = 15
        self.image = magic_image
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.direction = direction
    
    def update(self):
        self.rect.x += (self.direction * self.speed)
        if self.rect.right < 0 or self.rect.left > SCREEN_WIDTH:
            self.kill()

        if pygame.sprite.spritecollide(player, magic_group, False):
            if player.alive:
                player.health -= 20
                self.kill()
        for enemy in enemy_group:
            if pygame.sprite.spritecollide(enemy, magic_group, False):
             if enemy.alive:
                    enemy.health -= 20
                    player.score += 10
                    self.kill()



#create sprite groups
magic_group = pygame.sprite.Group()
enemy_group = pygame.sprite.Group()
item_box_group = pygame.sprite.Group()



#create item boxes
item_box = ItemBox('heal', 20, 550)
item_box_group.add(item_box)
item_box = ItemBox('heal', 950, 550)
item_box_group.add(item_box)
item_box = ItemBox('mana', 700, 550)
item_box_group.add(item_box)
item_box = ItemBox('mana', 300, 550)
item_box_group.add(item_box)




player = Human('hero', 120, 200, 3, 5, 20)



enemy = Human('enemy', 300, 200, 3, 3, 20)
enemy2 = Human('enemy', 500, 200, 3, 3, 20)
enemy3 = Human('enemy', 900, 200, 3, 3, 20)
enemy4 = Human('enemy', 400, 200, 3, 3, 20)
enemy5 = Human('enemy', 950, 200, 3, 3, 20)
enemy_group.add(enemy)
enemy_group.add(enemy2)
enemy_group.add(enemy3)
enemy_group.add(enemy4)
enemy_group.add(enemy5)




run = True
while run:

    clock.tick(FPS)

    draw_bg()
    #show mana
    draw_text(f'MP: {player.mp}', font, BLACK, 10, 30)
# show health
    draw_text(f'HP: {player.health}', font, BLUE, 10, 60)
    #show score
    draw_text(f'score: {player.score}', font, RED, 10, 90)
    #show instructions
    draw_text('WASD to move space to fire', font, BLUE, 10, 120)



    player.update()
    player.draw()
    
    
    enemy.ai()
    enemy.draw()
    enemy.update()
    enemy2.ai()
    enemy2.draw()
    enemy2.update()
    enemy3.ai()
    enemy3.draw()
    enemy3.update()
    enemy4.ai()
    enemy4.draw()
    enemy4.update()
    enemy5.ai()
    enemy5.draw()
    enemy5.update()

    #update and draw groups
    magic_group.update()
    item_box_group.update()
    magic_group.draw(screen)
    item_box_group.draw(screen)
    

    #player actions
    if player.alive:
        if shoot:
            player.shoot()
        if player.in_air:
            player.update_action(2) #jump
        elif moving_left or moving_right:
            player.update_action(1)#moving
        else:
            player.update_action(0)#idle
        player.move(moving_left, moving_right)
            



    for event in pygame.event.get():
        #for closing the game
        if event.type == pygame.QUIT:
            run = False
        #directional movement.
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                moving_left = True
            if event.key == pygame.K_d:
                moving_right = True
            if event.key == pygame.K_SPACE:
                shoot = True
            if event.key == pygame.K_w:
                player.jump = True
            if event.key == pygame.K_ESCAPE:
                run = False
            if player.alive == False:
                run = False
            


        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                moving_left = False
            if event.key == pygame.K_d:
                moving_right = False
            if event.key == pygame.K_SPACE:
                shoot = False
    
    pygame.display.update()
pygame.quit()